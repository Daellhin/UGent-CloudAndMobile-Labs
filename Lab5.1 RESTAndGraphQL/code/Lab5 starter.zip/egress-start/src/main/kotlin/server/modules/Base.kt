package be.ugent.idlab.predict.ocmt.egress.server.modules

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.plugins.statuspages.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Application.setup() {
    install(StatusPages) {
        exception<Throwable>(handler = ::onError)
        status(HttpStatusCode.NotFound, handler = ::onNotFound)
    }
    routing {
        trace {
            application.log.info("Incoming call: {}", it.call.request.uri.replace("\n", "\\n"))
        }
        get("/") {
            call.respond(HttpStatusCode.Companion.OK, "Hello world")
        }
    }
}
