package be.ugent.idlab.predict.ocmt.egress.server.modules.rest

import io.ktor.server.routing.*

/**
 * Returns an overview of all sources that ever submitted data
 *  ```json
 *  {
 *      "sources": ["location", ...]
 *  }
 *  ```
 */
fun Route.sources() {
    get("sources") {
        TODO()
    }
}
