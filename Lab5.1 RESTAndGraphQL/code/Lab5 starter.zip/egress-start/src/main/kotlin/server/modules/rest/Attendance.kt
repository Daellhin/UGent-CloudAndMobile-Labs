package be.ugent.idlab.predict.ocmt.egress.server.modules.rest

import io.ktor.server.routing.*

/**
 * Returns an overview of the attendance during the provided timestamps `start` and `stop` (epochs in ms) or using
 *  default values `Defaults.{start(),stop()}`, optionally filtered by a provided `source` value (tag), and returns
 *  them in a JSON structure with layout
 *  ```json
 *  {
 *      "events": [
 *          {
 *              "timestamp": 0,
 *              "id": "abc",
 *              "arrival": true,
 *              "source": "location"
 *          }, ...
 *      ]
 *  }
 *  ```
 */
fun Route.attendance() {
    get("attendance") {
        TODO()
    }
}
