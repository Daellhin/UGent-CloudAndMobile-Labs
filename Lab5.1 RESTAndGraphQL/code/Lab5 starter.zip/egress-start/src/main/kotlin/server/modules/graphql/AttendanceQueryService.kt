package be.ugent.idlab.predict.ocmt.egress.server.modules.graphql

import com.expediagroup.graphql.server.operations.Query

class AttendanceQueryService: Query {

    /**
     * Returns an overview of the attendance during the provided timestamps [start] and [stop] (epochs in ms) or using
     *  default values `Defaults.{start(),stop()}`, optionally filtered by a provided [source] value (tag), and returns
     *  them as a list of events with fields for timestamp (long), id (string), arrival flag (boolean) and
     *  source (string)
     */
    suspend fun attendance(
        start: String? = null,
        stop: String? = null,
        source: String? = null
    ) /* TODO: custom return type */ {
        TODO()
    }

}
