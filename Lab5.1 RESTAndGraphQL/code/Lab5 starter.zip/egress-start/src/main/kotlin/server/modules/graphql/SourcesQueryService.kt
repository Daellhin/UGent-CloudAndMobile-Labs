package be.ugent.idlab.predict.ocmt.egress.server.modules.graphql

import com.expediagroup.graphql.server.operations.Query

class SourcesQueryService: Query {

    /**
     * Returns an overview of the available sources, and returns them as a list
     */
    suspend fun sources() /* : TODO: custom return type */ {
        TODO()
    }

}
