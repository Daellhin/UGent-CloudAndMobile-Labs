package be.ugent.idlab.predict.ocmt.egress.server.modules.rest

import io.ktor.server.routing.*

/**
 * Returns the best fitting forecast given the timestamp`time` (epochs in ms) or using default
 *  value `Clock.System.now()`, according to the provided `source` value (tag), and returns
 *  them in a JSON structure with layout
 *  ```json
 *  {
 *      "source": "location",
 *      "method": "forecast-type",
 *      "predictions": [
 *          {
 *              "timestamp": 0,
 *              "value": 0
 *          }, ...
 *      ]
 *  }
 *  ```
 */
fun Route.forecast() {
    get("forecast") {
        TODO()
    }
}
