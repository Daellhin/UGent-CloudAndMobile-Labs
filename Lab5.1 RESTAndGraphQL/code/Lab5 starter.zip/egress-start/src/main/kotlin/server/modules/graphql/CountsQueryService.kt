package be.ugent.idlab.predict.ocmt.egress.server.modules.graphql

import com.expediagroup.graphql.server.operations.Query

class CountsQueryService: Query {

    /**
     * Returns an overview of the count changes during the provided timestamps [start] and [stop] (epochs in ms) or using
     *  default values `Defaults.{start(),stop()}`, optionally filtered by a provided [source] value (tag), and returns
     *  them as a list of events with fields for timestamp (long), value (int) and source (string)
     */
    suspend fun counts(
        start: String? = null,
        stop: String? = null,
        source: String? = null
    ) /* TODO: custom return type */ {
        TODO()
    }

}
