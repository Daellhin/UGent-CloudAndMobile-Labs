package be.ugent.idlab.predict.ocmt.android.data.service

import android.content.Context
import be.ugent.idlab.predict.ocmt.android.util.userSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Sources service responsible for interacting with all registered sources in the egress API.
 *  Uses the active session's token retrieved through `context.userSession` to create an authorized
 *  request to the egress instance in the cloud, retrieving the list of sources.
 *
 * These sources are made available through a StateFlow: the initial value is an empty list, which
 *  changes to the available sources whenever `refresh()` is called. Furthermore, this value should
 *  be updated whenever the session changes (e.g. user signs in), so the user experience is smooth.
 */
class SourcesService(
    private val context: Context,
    private val scope: CoroutineScope
) {

    private val _sources = MutableStateFlow<List<String>>(emptyList())
    val sources = _sources.asStateFlow()

    init {
        scope.launch {
            context.userSession.state.collect {
                if (it != null) {
                    refresh()
                } else {
                    // no one is signed in, no sources should be available
                    _sources.update { emptyList() }
                }
            }
        }
    }

    fun refresh() {
        scope.launch {
            // TODO: contact the `sources` endpoint from egress using an authorized call and use
            //  the retrieved values to update the `_sources` StateFlow
        }
    }

}
