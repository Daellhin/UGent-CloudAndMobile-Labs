package be.ugent.idlab.predict.ocmt.android.data.service

import android.content.Context

/**
 * Attendance service responsible for interacting with attendance information exposed by the egress API.
 *  Uses the active session's token retrieved through `context.userSession` to create an authorized
 *  request to the egress instance in the cloud, retrieving attendance information using parameters
 *  set by the user (or defaults). These parameters are similar to the ones found in the egress API:
 *   * source (string): directly used in egress
 *   * interval (duration): used to calculate the oldest time to retrieve data samples
 *     for (retrieving all data between `now - interval` & `now`); defaults to 5 minutes
 *   * period (duration): frequency at which new data is requested; defaults to 20 seconds
 *
 * Results are exposed through a `Flow`, with its values being observed and shown in UI.
 */
class AttendanceService(
    private val context: Context
)
