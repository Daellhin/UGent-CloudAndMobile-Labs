package be.ugent.idlab.predict.ocmt.android.data.service

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.serialization.Serializable
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/**
 * Counts service responsible for interacting with raw count observations exposed by the egress API.
 *  Uses the active session's token retrieved through `context.userSession` to create an authorized
 *  request to the egress instance in the cloud, retrieving raw count information using parameters
 *  set by the user (or defaults). These parameters are similar to the ones found in the egress API:
 *   * source (string): directly used in egress
 *   * interval (duration): used to calculate the oldest time to retrieve data samples
 *     for (retrieving all data between `now - interval` & `now`); defaults to 5 minutes
 *   * period (duration): frequency at which new data is requested; defaults to 20 seconds
 *
 * Results are exposed through a `Flow`, with its values being observed and shown in UI.
 */
class CountsService(
    private val context: Context
) {

    @Serializable
    data class Response(
        val events: List<Event>
    ) {
        @Serializable
        data class Event(
            val timestamp: Long,
            val value: Int,
            val source: String?
        )
    }

    fun observe(
        source: String,
        interval: Duration = 5.minutes,
        period: Duration = 20.seconds
    ): Flow<List<Response.Event>> {
        // TODO: periodically call the relevant egress endpoint using these arguments,
        //  updating the flow's value. Example of such flow creation can be found at
        //  https://kotlinlang.org/docs/flow.html#flows
        return emptyFlow()
    }

}
