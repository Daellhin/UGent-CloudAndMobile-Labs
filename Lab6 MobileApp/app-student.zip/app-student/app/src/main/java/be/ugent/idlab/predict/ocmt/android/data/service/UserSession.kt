package be.ugent.idlab.predict.ocmt.android.data.service

import be.ugent.idlab.predict.ocmt.android.data.Credentials
import be.ugent.idlab.predict.ocmt.android.data.User
import be.ugent.idlab.predict.ocmt.android.data._errors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * User session instance, responsible for containing the session token obtained when logging in,
 *  logging back out, and providing the ability for users to register new accounts.
 */
class UserSession(
    private val scope: CoroutineScope
) {

    private val _state = MutableStateFlow<User?>(null)
    val state = _state.asStateFlow()

    fun login(
        credentials: Credentials,
        onSuccess: () -> Unit,
        onFailure: () -> Unit
    ) {
        scope.launch {
            login(credentials)
                .onFailure { onFailure() }
                .onFailure { _errors.emit(it) }
                .onSuccess { session ->
                    _state.emit(session)
                    onSuccess()
                }
        }
    }

    fun logout() {
        _state.update { null }
    }

    fun register(
        credentials: Credentials,
        onSuccess: () -> Unit,
        onFailure: () -> Unit
    ) {
        scope.launch {
            register(credentials)
                .onFailure { onFailure() }
                .onFailure { _errors.emit(it) }
                .onSuccess { onSuccess() }
        }
    }

    private suspend fun login(credentials: Credentials): Result<User> {
        // TODO: contact the egress login endpoint to get a token, and return that token
        //  as a result type if successful
        return runCatching { TODO("Not yet implemented") }
    }

    private suspend fun register(credentials: Credentials): Result<Unit> {
        // TODO: contact the egress register endpoint with the provided credentials, returning
        //  an empty OK result if successful
        return runCatching { TODO("Not yet implemented") }
    }

}
