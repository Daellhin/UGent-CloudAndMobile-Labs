from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    bucket: str = 'replace-me'
    influx_org: str = 'cloud2023'
    log_level: str = 'INFO'
    influx_token: str
    influx_url: str
