import logging
from fastapi import FastAPI
from functools import reduce
from influxdb_client import InfluxDBClient
from influxdb_client.client.write_api import SYNCHRONOUS
from influxdb_client.domain.write_precision import WritePrecision
from typing import List

from config import Settings
from models import RfidDataPoint, RecentData

app = FastAPI()
settings = Settings()
influx = InfluxDBClient(url=settings.influx_url, token=settings.influx_token, org=settings.influx_org)
logger = logging.getLogger(__name__)
logger.setLevel(settings.log_level.upper())


@app.get("/", description="Example route, also used for healthchecks")
async def root():
    return {"message": "Hello World"}


@app.post("/data/", status_code=201, description="Store sensor data in InfluxDB")
async def post_data(data: RfidDataPoint):
    raise NotImplementedError

@app.get("/data/", description="Retrieve recent data")
async def get_data(since: str = "1h") -> RecentData:
    raise NotImplementedError

@app.get("/count/", description="Retrieve last count")
async def get_count() -> int:
    raise NotImplementedError

@app.get("/current/", description="Get tags currently inside")
async def get_current() -> List[str]:
    raise NotImplementedError
    return [record.values.get("tag") for table in result for record in table.records]
